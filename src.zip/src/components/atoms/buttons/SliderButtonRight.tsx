import React, { useRef } from 'react';
import cn from 'classnames';
import { ArrowRightIcon } from '../icons/ArrowRightIcon';

type SliderButtonRightProps = {
  onClick: () => void;
  disabled: boolean;
};

export const SliderButtonRight: React.FC<SliderButtonRightProps> = ({
  onClick,
  disabled,
}) => {
  const btnRef = useRef<HTMLButtonElement>(null);

  return (
    <button
      ref={btnRef}
      onClick={onClick}
      className={cn(
        `
        flex items-center justify-center
        w-[32px] h-[32px]
        cursor-pointer
        box-border
        rounded-full
        transition-all duration-200
        disabled:border-elements
        bg-transparent
        self-center
        `,
        { 'hover:border-custom-primary': !disabled },
      )}
    >
      <ArrowRightIcon
        className={disabled ? 'text-icons' : 'text-custom-primary'}
      />
    </button>
  );
};
