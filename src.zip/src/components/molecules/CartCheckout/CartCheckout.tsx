/* eslint-disable @typescript-eslint/no-explicit-any */
import * as React from 'react';
import { PrimaryButton } from '../../atoms/buttons';
import { useCart } from 'react-use-cart';
import { useCartSyncManager } from '@/hooks/useCartSyncManager';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export const CartCheckout: React.FC = () => {
  const { cartTotal, totalItems } = useCart();
  useCartSyncManager();

  const [showForm, setShowForm] = React.useState(false);
  const [deliveryType, setDeliveryType] = React.useState<
    'nova_poshta' | 'courier' | ''
  >('');
  const [form, setForm] = React.useState({
    name: '',
    email: '',
    address: '',
    branch: '',
    cardNumber: '',
    expiry: '',
    cvc: '',
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>,
  ) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    console.log('🧾 Замовлення:', { ...form, deliveryType });
    // Тут буде логіка збереження в Supabase або виклик RPC
  };

  return (
    <div className="flex flex-col gap-6 p-6 border border-solid border-elements rounded-lg">
      <div className="flex flex-col justify-center items-center">
        <span className="text-h2 font-extrabold">${cartTotal}</span>
        <span className="text-body font-semibold">
          Total for {totalItems} items
        </span>
      </div>

      <div className="border border-solid border-elements" />

      {!showForm ?
        <PrimaryButton
          text="Checkout"
          onSelect={() => setShowForm(true)}
        />
      : <form
          className="flex flex-col gap-4"
          onSubmit={(e) => {
            e.preventDefault();
            handleSubmit();
          }}
        >
          <div>
            <Label htmlFor="deliveryType">Тип доставки</Label>
            <select
              name="deliveryType"
              value={deliveryType}
              onChange={(e) => setDeliveryType(e.target.value as any)}
              className="w-full border rounded px-2 py-1"
            >
              <option value="">Оберіть тип</option>
              <option value="nova_poshta">Нова Пошта (відділення)</option>
              <option value="courier">Кур’єр</option>
            </select>
          </div>

          {deliveryType === 'nova_poshta' && (
            <div>
              <Label htmlFor="branch">Відділення Нової Пошти</Label>
              <Input
                name="branch"
                value={form.branch}
                onChange={handleChange}
                placeholder="Напр. №5, Хмельницький"
              />
            </div>
          )}

          <div>
            <Label htmlFor="name">Ім’я</Label>
            <Input
              name="name"
              value={form.name}
              onChange={handleChange}
            />
          </div>

          <div>
            <Label htmlFor="email">Email</Label>
            <Input
              name="email"
              value={form.email}
              onChange={handleChange}
            />
          </div>

          <div>
            <Label htmlFor="address">Адреса доставки</Label>
            <Input
              name="address"
              value={form.address}
              onChange={handleChange}
            />
          </div>

          <div>
            <Label htmlFor="cardNumber">Номер карти</Label>
            <Input
              name="cardNumber"
              value={form.cardNumber}
              onChange={handleChange}
              placeholder="1234 5678 9012 3456"
            />
          </div>

          <div className="flex gap-4">
            <div className="flex-1">
              <Label htmlFor="expiry">MM/YY</Label>
              <Input
                name="expiry"
                value={form.expiry}
                onChange={handleChange}
                placeholder="12/25"
              />
            </div>
            <div className="flex-1">
              <Label htmlFor="cvc">CVC</Label>
              <Input
                name="cvc"
                value={form.cvc}
                onChange={handleChange}
                placeholder="123"
              />
            </div>
          </div>

          <PrimaryButton text="Оформити замовлення" />
        </form>
      }
    </div>
  );
};
