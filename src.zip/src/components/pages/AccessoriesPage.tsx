import { ProductsPage } from './ProductsPage';

export const AccessoriesPage = () => (
  <ProductsPage
    category="accessories"
    titleKey="accessories"
  />
);
